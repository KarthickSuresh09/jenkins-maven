## Jenkins_Projects

This is Maven Project

- Free Style Project
- Pipeline As Code - First real pipeline demo with the pipeline-as-code concept
- Demo on Dockerize Application
- Jenkins Plugins for Docker
- Post Build in Jenkins Demo
- Dockerize Build, Deploy & Run Container from Jenkins - 2nd Pipeline demo with docker build, deploy, run


